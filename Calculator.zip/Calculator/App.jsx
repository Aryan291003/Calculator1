import { useState } from 'react';
import { SafeAreaView, StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import { myColors } from './src/styles/Colors';
import { ThemeContext } from './src/context/ThemeContext';
import MyKeyboard from './src/components/MyKeyboard';
import ConversionMenu from './src/components/ConversionMenu';
import Button from './src/components/Button';

export default function App() {
  const [theme, setTheme] = useState('light');
  const [menuVisible, setMenuVisible] = useState(false);

  return (
    <ThemeContext.Provider value={theme}>
      <SafeAreaView
        style={[
          styles.container,
          { backgroundColor: theme === 'light' ? myColors.light : 'black' },
        ]}
      >


        <TouchableOpacity
          style={styles.conversionButton}
          onPress={() => setMenuVisible(true)}>
          <Text style={styles.conversionButtonText}>☰</Text>
        </TouchableOpacity>

        
        <ConversionMenu
          isVisible={menuVisible}
          onClose={() => setMenuVisible(false)}
        />

        <Switch
          value={theme === 'dark'}
          onValueChange={() =>
            setTheme(theme === 'light' ? 'dark' : 'light')
          }
        />
      
        <MyKeyboard />
      </SafeAreaView>
    </ThemeContext.Provider>
 
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: myColors.light,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  conversionButton: {
    position: 'absolute',
    top: 20, 
    left: 20, 
    backgroundColor: myColors.orange,
    padding: 10,
    borderRadius: 5,
    zIndex: 10, 
  },
  conversionButtonText: {
    color: myColors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
});
